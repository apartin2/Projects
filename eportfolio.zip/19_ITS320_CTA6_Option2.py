##Create two lists that takes up to 10 values each and using list comprehension create both lists
firstList = [int(i) for i in input('Enter the first list (no more than 10 values) to be used in Cartesian product evaluation: ').split()]

##Raise an exception if more than 10 values are input by user
if len(firstList) > 10:
    raise Exception('Items exceeds the maximum allowed length of 10')

secondList = [int(i) for i in input('Enter the second list (no more than 10 values) to be used in Cartesian product evaluation: ').split()]

##Raise an exception if more than 10 values are input by user
if len(secondList) > 10:
    raise Exception('Items exceeds the maximum allowed length of 10')

##Create variable to hold output of (x,y) by combining both lists in Cartesian product fashion
CartProd = [(x,y) for x in firstList for y in secondList]

##output our new variable of Cartesian products
print('Cartesian Product: AxB= ', CartProd)
