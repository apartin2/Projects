class main:
    #define initializing function & set string value to blank
    def __init__(self):
        self.string1 = ""

    def ask(self):
        #Prompt user for inputs and return that value to be stored
        self.string_value = input('Enter a string to be stored, concatenated, and reversed: ')
        return self.string_value
        
#define an object of the main class & call its member function ask() to prompt user for inputs
prog = main()
FirstString = prog.ask()
SecondString = prog.ask()
ThirdString = prog.ask()

#define our reverse function using 3 string inputs
def reverse(first, second, third):
    #return the reverse order of the concatenated string values
    return third[::-1]+second[::-1]+first[::-1]

#print concatenation by calling our reverse function defined above using provided input as passed arguments
print("Concatenation of strings in reverse order: ", reverse(FirstString, SecondString, ThirdString))


