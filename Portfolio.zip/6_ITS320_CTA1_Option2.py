numerator = int(input('Enter numerator:\n')) #assigns value for numerator
denominator = int(input('Enter denominator:\n')) #assigns value for denominator
print(numerator//denominator) #performs and prints integer division
print(numerator/denominator) #performs and prints float division
print(numerator%denominator) #performs and prints modulo division
