class Auto:
    def __init__(self, make, model, color, year, mileage): ##initialization of Auto variables
        self.make = make
        self.model = model
        self.color = color
        self.year = year
        self.mileage = mileage

    def add_vehicle(): ##function to add vehicle to text file
        make = input("Enter make: ")
        model = input("Enter model: ")
        color = input("Enter color: ")
        year = input("Enter year: ")
        mileage = input("Enter mileage: ")
        
        vehicles = Auto(make, model, color, year, mileage) ##places inputs into Auto variables to be added to the list
        vehicle_list = [vehicles.make, vehicles.model, vehicles.color, vehicles.year, vehicles.mileage] ##adds variables into vehicle list using modifications below
        ##write inventory list into vehicle.txt for export
        for item in vehicle_list:
            auto_file = open('vehicle.txt', 'a') ##create & open text file for appending items
            auto_file.write("%s\t" % item)
            auto_file.write("\n")
            auto_file.close()
        print("Your record has been successfully added to the inventory")

    def delete_vehicle(): ##function to delete item from text file
        del_record = input("Enter record to delete: ")

        with open("vehicle.txt", "r+") as file:
            new_file = file.readlines()
            file.seek(0)
            for line in new_file:
                if del_record not in line:
                    file.write(line)
            file.truncate()
        print("Successfully deleted record from inventory.")

    def set_make(self, make): ##allows for modificaiton of make variable
        self.make = make

    def get_make(self): ##returns value for make variable
        return self.make

    def set_model(self, model): ##allows for modification of model variable
        self.model = model

    def get_model(self): ##returns value for model variable
        return self.model

    def set_color(self, color): ##allows for modification of color variable
        self.color = color

    def get_color(self): ##returns value for color variable
        return self.color

    def set_year(self, year): ##allows for modification of year variable
        self.year = year

    def get_year(self): ##returns value for year variable
        return self.year

    def set_mileage(self, mileage): ##allows for modification of mileage variable
        self.mileage = mileage

    def get_mileage(self): ##returns value for mileage variable
        return self.mileage
##present running list for user to continually update and delete inventory list as needed
while True:
    print(" 1. Add a Vehicle\n 2. Delete a Vehicle\n 3. Exit/Quit\n Inventory is output to text file: 'vehicle.txt'")
    ans = input("What would you like to do? ")
    if ans == '1':
        Auto.add_vehicle()
    elif ans == '2':
        Auto.delete_vehicle()
    elif ans == '3':
        print("\n Goodbye.")
        break
    elif ans != "":
        print("\n Invalid Entry")

