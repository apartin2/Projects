value_list = []
i=0
while i < 5:
    num = float(input('Enter a number: '))
    value_list.append(num)
    i += 1

average = sum(value_list)/5
print ('Average: ', average)
print ('Maximum: ', max(value_list))
print ('Minimum: ', min(value_list))
