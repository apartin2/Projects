stringS = input("Please input a string of less than 50 characters\n") #Assign string based on user input of less than 50 char
if(int(len(stringS) < 50)): #ensure string is less than 50 char & continue if so
    print(stringS.isalnum()) #checks if all char are alphanumeric
    print(stringS.isalpha()) #checks if all char are alphabetical
    print(stringS.isdigit()) #checks if all char are digits
    print(stringS.islower()) #checks if all char are lowercase
    print(stringS.isupper()) #checks if all char are uppercase
else: #if entry is >= 50 char, prompt user to try again and exit
    print("Entry too long. Please try again.\n")
